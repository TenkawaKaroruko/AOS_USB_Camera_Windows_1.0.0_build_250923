'''
------------------------------------------------------------------
Project Name: AOS USB Camera Python Windows
Version: 1.0.0 build 250923
Issuer:Japan Kyoto Aroma Ocean Sauce Digital Technology Studio
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
(EN)

Utilizing the Project Declaration:

Open Source Project License & Usage Terms
 
1. Scope of Permitted Use (Non-Commercial & Commercial)
 
1.1 Freely Usable & Customizable Files
 
Except for the icon.png file and the internal AOS_Pixel_Font_Pro font file, all other files in the source code project (including but not limited to Python source code files, configuration files, non-AOS_Pixel_Font_Pro font files, and document files) are permitted for the following uses, without additional authorization from the project publisher:
 
- Non-commercial use: Free use, copy, modify, and customize for personal learning, research, or non-profit organizational operations.
- Commercial use: Permitted for secondary development and integration into commercial products/services, provided that the requirements in Section 2 are strictly followed.
 
1.2 Restricted Files (Prohibited from Commercial Use)
 
The following two files are strictly prohibited from any commercial use (including but not limited to being embedded in commercial software, used in commercial advertisements, or included in paid products/services), and can only be used for non-commercial purposes (e.g., personal test versions of the project):
 
- icon.png: The project's default icon file; any commercial use (such as replacing the icon of commercial software or using it in commercial promotion materials) is not allowed.
- AOS_Pixel_Font_Pro font file: The internal dedicated font of the project; commercial use (such as embedding it in paid software for user display or using it in commercial design works) is not allowed. For commercial scenarios requiring font functionality, users must replace it with a legally licensed commercial font or an open-source font that permits commercial use.
 
2. Mandatory Requirements for Commercial Secondary Development
 
When using the project's source code for commercial secondary development (including but not limited to developing commercial software, providing paid services based on the source code, or integrating the source code into commercial systems), the following requirements must be met to comply with copyright regulations:
 
2.1 Source Code Attribution Notification
 
A clear and visible attribution statement must be made in the following locations of the commercial product/service to indicate the use of this open-source project's source code:
 
- Software interface: Display the attribution in the "About" page, "Copyright Information" page, or a fixed notification area (font size not smaller than the default text size of the interface).
- Official documentation: Include the attribution in the product's user manual, technical documentation, or commercial promotion materials (if the source code is a core component of the product).
- Standard attribution format: Must use the following fixed notation (replace "[corresponding version number]" with the specific version of the source code used, e.g., V1.2.0):
"This product uses the source code of Open Source AOSAOS USB Camera Python Windows ([corresponding version number])"
 
2.2 Open-Source Obligation for Modified Source Code
 
For any modified parts of the project's source code (including functional extensions, bug fixes, or structural adjustments) in commercial development, if the modified code is distributed externally (e.g., provided to third-party partners or included in the released commercial software), the modified source code must be made publicly available for free through a publicly accessible platform (e.g., GitHub, Gitee). The release must be accompanied by a change log documenting the differences from the original open-source version to ensure transparency of the modified content.
 
3. Liability Disclaimer
 
The project publisher only provides the source code in accordance with the terms of this license and does not assume any legal liability for the following situations:
 
- Legal risks from non-compliance: Any legal liabilities (including but not limited to copyright infringement claims, fines, or compensation) arising from failure to comply with the terms of this license (e.g., unauthorized commercial use of restricted files, failure to provide attribution, or refusal to open-source modified code) shall be borne solely by the user.
- Risks of use: The source code is provided "as is" without guarantees of correctness, stability, or suitability for specific commercial scenarios. The project publisher shall not be liable for any losses (including but not limited to direct economic losses, business interruption losses, or data loss) caused by the use, modification, or commercial application of the source code.
- Third-party claims: If the commercial product developed based on the source code infringes the intellectual property rights of a third party (e.g., due to the user's addition of non-open-source third-party components), the user shall independently handle the dispute and bear the corresponding liability, and the project publisher shall not be involved.
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
(CN)

利用项目声明：

开源项目许可及使用条款
 
1. 许可使用范围（非商业与商业场景）
 
1.1 可自由使用及定制的文件
 
除 icon.png 文件与内置 AOS_Pixel_Font_Pro 字体文件外，源代码项目中的所有其他文件（包括但不限于 Python 源代码文件、配置文件、非 AOS_Pixel_Font_Pro 字体文件、文档文件），无需经项目发布方额外授权，可用于以下场景：
 
- 非商业用途：可免费用于个人学习、研究或非营利性组织运营，包括复制、修改与定制。
- 商业用途：可用于二次开发并集成至商业产品/服务中，但需严格遵守本条款第2部分的要求。
 
1.2 受限文件（禁止商业使用）
 
以下两类文件严禁用于任何商业场景（包括但不限于嵌入商业软件、用于商业广告、包含在付费产品/服务中），仅可用于非商业用途（如项目个人测试版本）：
 
- icon.png：项目默认图标文件，不得用于商业软件图标替换、商业宣传物料制作等商业场景。
- AOS_Pixel_Font_Pro 字体文件：项目内置专用字体文件，不得用于付费软件字体嵌入、商业设计作品制作等商业场景。若商业场景需实现字体功能，用户需替换为具备合法授权的商业字体，或允许商业使用的开源字体。
 
2. 商业二次开发的强制性要求
 
使用本项目源代码进行商业二次开发（包括但不限于开发商业软件、基于源代码提供付费服务、将源代码集成至商业系统）时，需满足以下要求以符合版权规定：
 
2.1 源代码归属声明
 
需在商业产品/服务的以下位置，以清晰可见的方式标注归属，说明使用了本开源项目的源代码：
 
- 软件界面：在“关于”页面、“版权信息”页面或固定通知区域标注（字体大小不小于界面默认文本大小）。
- 官方文档：在产品用户手册、技术文档或商业宣传资料（若源代码为产品核心组件）中包含归属声明。
- 标准归属格式：需使用以下固定表述（将“[对应版本号]”替换为所使用源代码的具体版本，如 V1.2.0）：
“本产品使用开源项目 AOSAOS USB Camera Python Windows（[对应版本号]）的源代码”
 
2.2 修改后源代码的开源义务
 
商业开发中对本项目源代码的任何修改（包括功能扩展、漏洞修复、结构调整），若修改后的代码对外分发（如提供给第三方合作方、包含在发布的商业软件中），则必须通过可公开访问的平台（如 GitHub、Gitee）将修改后的源代码免费公开。发布时需附带修改日志，说明与原开源版本的差异，确保修改内容透明。
 
3. 责任免责声明
 
项目发布方仅依据本许可条款提供源代码，对以下情形不承担任何法律责任：
 
- 违规使用的法律风险：因未遵守本许可条款（如未经授权商业使用受限文件、未标注归属、拒绝公开修改后代码）引发的法律责任（包括但不限于版权侵权索赔、罚款、赔偿），均由用户自行承担。
- 使用风险：源代码按“现状”提供，不保证其正确性、稳定性及对特定商业场景的适用性。因使用、修改或商业应用源代码导致的损失（包括但不限于直接经济损失、业务中断损失、数据丢失），项目发布方不承担责任。
- 第三方索赔：若基于源代码开发的商业产品侵犯第三方知识产权（如用户添加非开源第三方组件所致），用户需自行处理纠纷并承担相应责任，项目发布方不参与其中。
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
'''
# 导入所需的库
# Import required libraries
# 必要なライブラリをインポート
import cv2
import time
from datetime import datetime
from PIL import Image, ImageDraw, ImageFont
import numpy as np
from colorama import init, Fore, Style
import threading
import queue
import re
import json
import os
import tkinter as tk
from tkinter import ttk
from PIL import Image, ImageTk
import tkinter.font as tkFont
import sys
import contextlib
import argparse

# 初始化colorama，自动重置颜色
# Initialize colorama with auto reset
# coloramaを自動リセットで初期化
init(autoreset=True)

# 版本信息
# Version information
# バージョン情報
VERSION = "1.0.0"
BUILD_DATE = "250923"
VERSION_INFO = f"AOS USB Camera Python Windows Version:{VERSION} build {BUILD_DATE}"

# 配置目录和文件路径
# Configuration directory and file paths
# 設定ディレクトリとファイルパス
CONFIG_DIR = "./config"
CONFIG_FILE = os.path.join(CONFIG_DIR, "osd_config.json")
IMAGE_DIR = "./images"
VIDEO_DIR = "./videos"
LOG_DIR = "./logs"
LOG_FILE = os.path.join(LOG_DIR, f"camera_log_{datetime.now().strftime('%Y%m%d')}.log")

# 字体相关设置
# Font related settings
# フォント関連の設定
FONT_PATH = "./font/osd_font.ttf"
FONT_SIZE = 24
CHAR_SPACING = 2
BRIGHTNESS_THRESHOLD = 127
TEXT_POS_X = 20
TEXT_POS_Y = 20
CHANNEL_NAME_POS_Y = 50

# 全局变量
# Global variables
# グローバル変数
current_font_size = FONT_SIZE
font = None
osd_color = None
channel_name = "Camera 01"
time_pos = [TEXT_POS_X, TEXT_POS_Y]
channel_pos = [TEXT_POS_X, CHANNEL_NAME_POS_Y]
adjustment_window = None
adjustment_running = False
show_adjustment_window = False
frame_for_adjustment = None
camera_width = 0
camera_height = 0
command_listener_running = True
time_format = "a"

# 图像和视频相关变量
# Image and video related variables
# 画像とビデオ関連の変数
image_count = 0
video_recording = False
video_writer = None
video_filename = None
video_infinite_mode = False

# 确保日志目录存在
# Ensure log directory exists
# ログディレクトリが存在することを確認
def ensure_log_dir():
    if not os.path.exists(LOG_DIR):
        os.makedirs(LOG_DIR)
        print(Fore.GREEN + f"Created log directory: {LOG_DIR}" + Style.RESET_ALL)

# 记录日志消息
# Log a message
# メッセージをログに記録
def log_message(message):
    ensure_log_dir()
    
    now = datetime.now()
    timestamp = now.strftime("%Y-%m-%d %H:%M:%S")
    
    log_entry = f"[{timestamp}] {message}\n"
    
    try:
        with open(LOG_FILE, 'a', encoding='utf-8') as f:
            f.write(log_entry)
    except Exception as e:
        print(Fore.RED + f"Error writing to log file: {e}" + Style.RESET_ALL)

# 确保配置目录存在
# Ensure config directory exists
# 設定ディレクトリが存在することを確認
def ensure_config_dir():
    if not os.path.exists(CONFIG_DIR):
        os.makedirs(CONFIG_DIR)
        print(Fore.GREEN + f"Created config directory: {CONFIG_DIR}" + Style.RESET_ALL)
        log_message(f"Created config directory: {CONFIG_DIR}")

# 确保图像目录存在
# Ensure image directory exists
# 画像ディレクトリが存在することを確認
def ensure_image_dir():
    if not os.path.exists(IMAGE_DIR):
        os.makedirs(IMAGE_DIR)
        print(Fore.GREEN + f"Created image directory: {IMAGE_DIR}" + Style.RESET_ALL)
        log_message(f"Created image directory: {IMAGE_DIR}")

# 确保视频目录存在
# Ensure video directory exists
# ビデオディレクトリが存在することを確認
def ensure_video_dir():
    if not os.path.exists(VIDEO_DIR):
        os.makedirs(VIDEO_DIR)
        print(Fore.GREEN + f"Created video directory: {VIDEO_DIR}" + Style.RESET_ALL)
        log_message(f"Created video directory: {VIDEO_DIR}")

# 加载配置
# Load configuration
# 設定を読み込む
def load_config():
    global current_font_size, osd_color, channel_name, time_pos, channel_pos, time_format
    
    ensure_config_dir()
    
    if os.path.exists(CONFIG_FILE):
        try:
            with open(CONFIG_FILE, 'r') as f:
                config = json.load(f)
                
            if 'font_size' in config:
                current_font_size = config['font_size']
                
            if 'osd_color' in config:
                color_value = config['osd_color']
                if color_value == 'auto':
                    osd_color = None
                else:
                    osd_color = tuple(int(color_value[i:i+2], 16) for i in (0, 2, 4))
                    
            if 'channel_name' in config:
                channel_name = config['channel_name']
                
            if 'time_pos' in config:
                time_pos = config['time_pos']
                
            if 'channel_pos' in config:
                channel_pos = config['channel_pos']
                
            if 'time_format' in config:
                time_format = config['time_format']
                
            print(Fore.GREEN + f"Configuration loaded from {CONFIG_FILE}" + Style.RESET_ALL)
            log_message(f"Configuration loaded from {CONFIG_FILE}")
        except Exception as e:
            print(Fore.RED + f"Error loading configuration: {e}" + Style.RESET_ALL)
            log_message(f"Error loading configuration: {e}")
            print(Fore.YELLOW + "Using default configuration." + Style.RESET_ALL)
            log_message("Using default configuration.")
    else:
        print(Fore.YELLOW + "No configuration file found. Using default configuration." + Style.RESET_ALL)
        log_message("No configuration file found. Using default configuration.")

# 保存配置
# Save configuration
# 設定を保存する
def save_config():
    global time_pos, channel_pos
    
    ensure_config_dir()
    
    config = {
        'font_size': current_font_size,
        'osd_color': 'auto' if osd_color is None else f"#{osd_color[0]:02x}{osd_color[1]:02x}{osd_color[2]:02x}",
        'channel_name': channel_name,
        'time_pos': time_pos,
        'channel_pos': channel_pos,
        'time_format': time_format
    }
    
    try:
        with open(CONFIG_FILE, 'w') as f:
            json.dump(config, f, indent=4)
        print(Fore.GREEN + f"Configuration saved to {CONFIG_FILE}" + Style.RESET_ALL)
        log_message(f"Configuration saved to {CONFIG_FILE}")
    except Exception as e:
        print(Fore.RED + f"Error saving configuration: {e}" + Style.RESET_ALL)
        log_message(f"Error saving configuration: {e}")

# 恢复默认设置
# Restore default settings
# デフォルト設定に戻す
def restore_default_settings():
    global current_font_size, osd_color, channel_name, time_pos, channel_pos, time_format
    
    current_font_size = FONT_SIZE
    print(Fore.GREEN + f"Font size restored to default: {current_font_size}" + Style.RESET_ALL)
    log_message(f"Font size restored to default: {current_font_size}")
    
    osd_color = None
    print(Fore.GREEN + "OSD color restored to default: automatic" + Style.RESET_ALL)
    log_message("OSD color restored to default: automatic")
    
    channel_name = "Camera 01"
    print(Fore.GREEN + f"Channel name restored to default: {channel_name}" + Style.RESET_ALL)
    log_message(f"Channel name restored to default: {channel_name}")
    
    time_pos = [TEXT_POS_X, TEXT_POS_Y]
    print(Fore.GREEN + f"Time position restored to default: {time_pos}" + Style.RESET_ALL)
    log_message(f"Time position restored to default: {time_pos}")
    
    channel_pos = [TEXT_POS_X, CHANNEL_NAME_POS_Y]
    print(Fore.GREEN + f"Channel name position restored to default: {channel_pos}" + Style.RESET_ALL)
    log_message(f"Channel name position restored to default: {channel_pos}")
    
    time_format = "a"
    print(Fore.GREEN + f"Time format restored to default: {time_format}" + Style.RESET_ALL)
    log_message(f"Time format restored to default: {time_format}")
    
    save_config()

# 加载自定义字体
# Load custom font
# カスタムフォントを読み込む
def load_custom_font(font_path, font_size):
    try:
        return ImageFont.truetype(font_path, font_size)
    except IOError:
        print(Fore.RED + f"Error: Font file not found at {font_path}" + Style.RESET_ALL)
        log_message(f"Error: Font file not found at {font_path}")
        print(Fore.YELLOW + "Using default system font instead." + Style.RESET_ALL)
        log_message("Using default system font instead.")
        return ImageFont.load_default(size=font_size)

# 获取单个字符背景亮度
# Get single character background brightness
# 単一文字の背景輝度を取得
def get_single_char_bg_brightness(frame, char_x, char_y, char_width, font_height):
    bbox = (
        max(0, char_x), 
        max(0, char_y), 
        min(frame.shape[1], char_x + char_width), 
        min(frame.shape[0], char_y + font_height)
    )
    
    bg_roi = frame[bbox[1]:bbox[3], bbox[0]:bbox[2]]
    
    if bg_roi.size == 0:
        return BRIGHTNESS_THRESHOLD
    
    bg_gray = cv2.cvtColor(bg_roi, cv2.COLOR_BGR2GRAY)
    return np.mean(bg_gray)

# 绘制单个字符并动态调整颜色
# Draw single character with dynamic color
# 単一文字を描画し、動的に色を調整
def draw_single_char_with_dynamic_color(draw, char, char_x, char_y, font, frame):
    char_bbox = draw.textbbox((0, 0), char, font=font)
    char_width = char_bbox[2] - char_bbox[0]
    font_height = char_bbox[3] - char_bbox[1]
    
    if osd_color is not None:
        char_color = osd_color
    else:
        bg_brightness = get_single_char_bg_brightness(frame, char_x, char_y, char_width, font_height)
        char_color = (255, 255, 255) if bg_brightness < BRIGHTNESS_THRESHOLD else (0, 0, 0)
    
    draw.text((char_x, char_y), char, font=font, fill=char_color)
    
    return char_width + CHAR_SPACING

# 格式化时间
# Format time
# 時間をフォーマット
def format_time(now, format_code):
    weekday_map = {"0": "日", "1": "一", "2": "二", "3": "三", "4": "四", "5": "五", "6": "六"}
    weekday = f"星期{weekday_map[now.strftime('%w')]}"
    time_part = now.strftime("%H:%M:%S")
    
    if format_code == "a":
        return f"{now.strftime('%Y年%m月%d日')} {weekday} {time_part}"
    elif format_code == "b":
        return f"{now.strftime('%m月%d日%Y年')} {weekday} {time_part}"
    elif format_code == "c":
        return f"{now.strftime('%d日%m月%Y年')} {weekday} {time_part}"
    elif format_code == "d":
        return f"{now.strftime('%Y-%m-%d')} {weekday} {time_part}"
    elif format_code == "e":
        return f"{now.strftime('%m-%d-%Y')} {weekday} {time_part}"
    elif format_code == "f":
        return f"{now.strftime('%d-%m-%Y')} {weekday} {time_part}"
    elif format_code == "g":
        return f"{now.strftime('%Y/%m/%d')} {weekday} {time_part}"
    elif format_code == "h":
        return f"{now.strftime('%m/%d/%Y')} {weekday} {time_part}"
    elif format_code == "i":
        return f"{now.strftime('%d/%m/%Y')} {weekday} {time_part}"
    elif format_code == "j":
        return f"{now.strftime('%d/%m/%Y')} {time_part}"
    elif format_code == "k":
        return f"{now.strftime('%d-%m-%Y')} {time_part}"
    elif format_code == "l":
        return f"{now.strftime('%m月%d日%Y年')} {time_part}"
    elif format_code == "m":
        return f"{now.strftime('%Y年%m月%d日')} {time_part}"
    elif format_code == "n":
        return f"{now.strftime('%m月%d日%Y年')} {time_part}"
    elif format_code == "o":
        return f"{now.strftime('%Y-%m-%d')} {time_part}"
    elif format_code == "p":
        return f"{now.strftime('%Y/%m/%d')} {time_part}"
    elif format_code == "q":
        return f"{now.strftime('%m-%d-%Y')} {time_part}"
    elif format_code == "r":
        return f"{now.strftime('%m/%d/%Y')} {time_part}"
    elif format_code == "s":
        return f"{now.strftime('%Y年%m月%d日')} {time_part}"
    elif format_code == "t":
        return f"{now.strftime('%m月%d日%Y年')} {time_part}"
    else:
        return f"{now.strftime('%Y年%m月%d日')} {weekday} {time_part}"

# 添加实时时间到帧
# Add real-time time to frame
# フレームにリアルタイム時刻を追加
def add_realtime_time_with_single_char_color(frame, font):
    now = datetime.now()
    formatted_time = format_time(now, time_format)
    
    frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    pil_image = Image.fromarray(frame_rgb)
    draw = ImageDraw.Draw(pil_image)
    
    current_x = time_pos[0]
    current_y = time_pos[1]
    for char in formatted_time:
        char_total_width = draw_single_char_with_dynamic_color(draw, char, current_x, current_y, font, frame)
        current_x += char_total_width
    
    current_x = channel_pos[0]
    current_y = channel_pos[1]
    for char in channel_name:
        char_total_width = draw_single_char_with_dynamic_color(draw, char, current_x, current_y, font, frame)
        current_x += char_total_width
    
    return cv2.cvtColor(np.array(pil_image), cv2.COLOR_RGB2BGR)

# 捕获图像
# Capture images
# 画像をキャプチャ
def capture_image(count):
    global image_count
    
    ensure_image_dir()
    
    for i in range(count):
        ret, frame = cap.read()
        if not ret:
            print(Fore.RED + "Error: Failed to read frame from camera" + Style.RESET_ALL)
            log_message("Error: Failed to read frame from camera")
            break
        
        frame_with_osd = add_realtime_time_with_single_char_color(frame, font)
        
        now = datetime.now()
        filename = now.strftime("%Y%m%d_%H%M%S") + ".jpg"
        filepath = os.path.join(IMAGE_DIR, filename)
        
        cv2.imwrite(filepath, frame_with_osd)
        print(Fore.GREEN + f"Image saved: {filepath}" + Style.RESET_ALL)
        log_message(f"Image saved: {filepath}")
        
        time.sleep(1)
    
    print(Fore.GREEN + f"Successfully captured {count} images." + Style.RESET_ALL)
    log_message(f"Successfully captured {count} images.")

# 开始录制视频
# Start recording video
# ビデオ録画を開始
def start_video_recording(duration):
    global video_recording, video_writer, video_filename, video_infinite_mode
    
    ensure_video_dir()
    
    if video_recording:
        print(Fore.YELLOW + "Video recording is already in progress." + Style.RESET_ALL)
        log_message("Video recording is already in progress.")
        return
    
    now = datetime.now()
    video_filename = now.strftime("%Y%m%d_%H%M%S") + ".avi"
    video_filepath = os.path.join(VIDEO_DIR, video_filename)
    
    global camera_width, camera_height
    
    fourcc = cv2.VideoWriter_fourcc(*'XVID')
    video_writer = cv2.VideoWriter(video_filepath, fourcc, 30.0, (camera_width, camera_height))
    
    if not video_writer.isOpened():
        print(Fore.RED + f"Error: Failed to open video writer for {video_filepath}" + Style.RESET_ALL)
        log_message(f"Error: Failed to open video writer for {video_filepath}")
        return
    
    video_recording = True
    
    if duration.lower() == "i":
        video_infinite_mode = True
        print(Fore.GREEN + f"Started recording video to: {video_filepath}" + Style.RESET_ALL)
        log_message(f"Started recording video to: {video_filepath} (infinite mode)")
        print(Fore.GREEN + "Recording indefinitely. Use 'video:none' to stop." + Style.RESET_ALL)
        log_message("Recording indefinitely. Use 'video:none' to stop.")
    else:
        video_infinite_mode = False
        try:
            h, m, s = map(int, duration.split(':'))
            total_seconds = h * 3600 + m * 60 + s
            print(Fore.GREEN + f"Started recording video to: {video_filepath}" + Style.RESET_ALL)
            log_message(f"Started recording video to: {video_filepath} for {duration}")
            print(Fore.GREEN + f"Recording for {duration} ({total_seconds} seconds)." + Style.RESET_ALL)
            log_message(f"Recording for {duration} ({total_seconds} seconds).")
            
            def stop_recording_after_delay():
                time.sleep(total_seconds)
                if video_recording and not video_infinite_mode:
                    stop_video_recording()
            
            timer_thread = threading.Thread(target=stop_recording_after_delay)
            timer_thread.daemon = True
            timer_thread.start()
        except Exception as e:
            print(Fore.RED + f"Error parsing duration: {e}" + Style.RESET_ALL)
            log_message(f"Error parsing duration: {e}")
            stop_video_recording()

# 停止录制视频
# Stop recording video
# ビデオ録画を停止
def stop_video_recording():
    global video_recording, video_writer, video_filename, video_infinite_mode
    
    if not video_recording:
        print(Fore.YELLOW + "No video recording in progress." + Style.RESET_ALL)
        log_message("No video recording in progress.")
        return
    
    video_recording = False
    video_infinite_mode = False
    
    if video_writer is not None:
        try:
            video_writer.release()
            print(Fore.GREEN + f"Video recording stopped: {video_filename}" + Style.RESET_ALL)
            log_message(f"Video recording stopped: {video_filename}")
        except Exception as e:
            print(Fore.RED + f"Error releasing video writer: {e}" + Style.RESET_ALL)
            log_message(f"Error releasing video writer: {e}")
        finally:
            video_writer = None
            video_filename = None

# 抑制FFmpeg警告
# Suppress FFmpeg warnings
# FFmpegの警告を抑制
def suppress_ffmpeg_warnings():
    def decorator(func):
        def wrapper(*args, **kwargs):
            with open(os.devnull, 'w') as devnull:
                old_stderr = sys.stderr
                sys.stderr = devnull
                try:
                    return func(*args, **kwargs)
                finally:
                    sys.stderr = old_stderr
        return wrapper
    return decorator

# 写入视频帧
# Write video frame
# ビデオフレームを書き込む
@suppress_ffmpeg_warnings()
def write_video_frame(video_writer, frame):
    return video_writer.write(frame)

# 位置调整窗口类
# Position adjustment window class
# 位置調整ウィンドウクラス
class PositionAdjustmentWindow:
    def __init__(self, callback, initial_frame):
        self.callback = callback
        self.root = tk.Tk()
        self.root.title("OSD Position Adjustment")
        self.root.geometry("800x600")
        
        # 固定窗口大小，禁止调整
        # Fix window size, disable resizing
        # ウィンドウサイズを固定し、サイズ変更を禁止
        self.root.resizable(False, False)
        
        self.canvas = tk.Canvas(self.root, bg="black")
        self.canvas.pack(fill=tk.BOTH, expand=True)
        
        self.time_x = time_pos[0]
        self.time_y = time_pos[1]
        self.channel_x = channel_pos[0]
        self.channel_y = channel_pos[1]
        
        self.dragging = None
        self.drag_start_x = 0
        self.drag_start_y = 0
        
        self.canvas.bind("<Button-1>", self.on_mouse_down)
        self.canvas.bind("<B1-Motion>", self.on_mouse_drag)
        self.canvas.bind("<ButtonRelease-1>", self.on_mouse_up)
        
        self.root.protocol("WM_DELETE_WINDOW", self.on_window_close)
        
        self.frame = initial_frame.copy()
        self.pil_image = None
        self.photo = None
        
        try:
            self.tk_font = tkFont.Font(family=FONT_PATH, size=current_font_size)
        except:
            self.tk_font = tkFont.Font(size=current_font_size)
        
        self.root.after(100, self.init_canvas)
        
        self.canvas.create_text(400, 20, text="Drag the time or channel name to adjust their position", 
                              fill="white", font=("Arial", 12))
        self.canvas.create_text(400, 40, text="Close this window to save the positions", 
                              fill="white", font=("Arial", 12))
        
        log_message("OSD position adjustment window opened")

    # 初始化画布
    # Initialize canvas
    # キャンバスを初期化
    def init_canvas(self):
        if self.frame is None:
            return
            
        self.canvas.update()
        canvas_width = self.canvas.winfo_width()
        canvas_height = self.canvas.winfo_height()
        
        if canvas_width <= 1 or canvas_height <= 1:
            self.root.after(100, self.init_canvas)
            return
        
        frame_rgb = cv2.cvtColor(self.frame, cv2.COLOR_BGR2RGB)
        self.pil_image = Image.fromarray(frame_rgb)
        
        self.pil_image = self.pil_image.resize((canvas_width, canvas_height), Image.Resampling.LANCZOS)
        
        self.photo = ImageTk.PhotoImage(image=self.pil_image)
        
        self.canvas.delete("background")
        self.canvas.create_image(0, 0, anchor=tk.NW, image=self.photo, tags="background")
        
        self.draw_elements()
    
    # 更新帧
    # Update frame
    # フレームを更新
    def update_frame(self, frame):
        if frame is None:
            return
            
        self.frame = frame.copy()
        
        canvas_width = self.canvas.winfo_width()
        canvas_height = self.canvas.winfo_height()
        
        if canvas_width <= 1 or canvas_height <= 1:
            return
        
        frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        self.pil_image = Image.fromarray(frame_rgb)
        
        self.pil_image = self.pil_image.resize((canvas_width, canvas_height), Image.Resampling.LANCZOS)
        
        self.photo = ImageTk.PhotoImage(image=self.pil_image)
        
        self.canvas.delete("background")
        self.canvas.create_image(0, 0, anchor=tk.NW, image=self.photo, tags="background")
        
        self.draw_elements()
    
    # 绘制元素
    # Draw elements
    # 要素を描画
    def draw_elements(self):
        self.canvas.delete("element")
        
        now = datetime.now()
        formatted_time = format_time(now, time_format)
        
        current_x = self.time_x
        current_y = self.time_y
        time_text_id = None
        for char in formatted_time:
            char_bbox = self.tk_font.measure(char)
            char_width = char_bbox
            
            time_text_id = self.canvas.create_text(current_x, current_y, text=char, fill="white", 
                                      font=self.tk_font, tags=("element", "time"))
            
            current_x += char_width + CHAR_SPACING
        
        current_x = self.channel_x
        current_y = self.channel_y
        for char in channel_name:
            char_bbox = self.tk_font.measure(char)
            char_width = char_bbox
            
            self.canvas.create_text(current_x, current_y, text=char, fill="white", 
                                  font=self.tk_font, tags=("element", "channel"))
            
            current_x += char_width + CHAR_SPACING
    
    # 鼠标按下事件
    # Mouse down event
    # マウスダウンイベント
    def on_mouse_down(self, event):
        items = self.canvas.find_overlapping(event.x-5, event.y-5, event.x+5, event.y+5)
        
        for item in items:
            tags = self.canvas.gettags(item)
            if "element" in tags:
                text = self.canvas.itemcget(item, "text")
                
                if "time" in tags:
                    self.dragging = "time"
                    self.drag_start_x = event.x - self.time_x
                    self.drag_start_y = event.y - self.time_y
                    log_message(f"Started dragging time OSD at position ({self.time_x}, {self.time_y})")
                elif "channel" in tags:
                    self.dragging = "channel"
                    self.drag_start_x = event.x - self.channel_x
                    self.drag_start_y = event.y - self.channel_y
                    log_message(f"Started dragging channel name OSD at position ({self.channel_x}, {self.channel_y})")
                break
    
    # 鼠标拖动事件
    # Mouse drag event
    # マウスドラッグイベント
    def on_mouse_drag(self, event):
        if self.dragging:
            if self.dragging == "time":
                old_x, old_y = self.time_x, self.time_y
                self.time_x = event.x - self.drag_start_x
                self.time_y = event.y - self.drag_start_y
                
                self.time_x = max(0, min(self.time_x, self.canvas.winfo_width() - 200))
                self.time_y = max(0, min(self.time_y, self.canvas.winfo_height() - 20))
                
                if old_x != self.time_x or old_y != self.time_y:
                    log_message(f"Time OSD position changed from ({old_x}, {old_y}) to ({self.time_x}, {self.time_y})")
            else:
                old_x, old_y = self.channel_x, self.channel_y
                self.channel_x = event.x - self.drag_start_x
                self.channel_y = event.y - self.drag_start_y
                
                self.channel_x = max(0, min(self.channel_x, self.canvas.winfo_width() - 200))
                self.channel_y = max(0, min(self.channel_y, self.canvas.winfo_height() - 20))
                
                if old_x != self.channel_x or old_y != self.channel_y:
                    log_message(f"Channel name OSD position changed from ({old_x}, {old_y}) to ({self.channel_x}, {self.channel_y})")
            
            self.draw_elements()
            
            if self.callback:
                canvas_width = self.canvas.winfo_width()
                canvas_height = self.canvas.winfo_height()
                x_ratio = camera_width / canvas_width
                y_ratio = camera_height / canvas_height
                
                mapped_time_x = int(self.time_x * x_ratio)
                mapped_time_y = int(self.time_y * y_ratio)
                mapped_channel_x = int(self.channel_x * x_ratio)
                mapped_channel_y = int(self.channel_y * y_ratio)
                
                self.callback(mapped_time_x, mapped_time_y, mapped_channel_x, mapped_channel_y)
    
    # 鼠标释放事件
    # Mouse up event
    # マウスアップイベント
    def on_mouse_up(self, event):
        if self.dragging:
            if self.dragging == "time":
                log_message(f"Stopped dragging time OSD at position ({self.time_x}, {self.time_y})")
            else:
                log_message(f"Stopped dragging channel name OSD at position ({self.channel_x}, {self.channel_y})")
        self.dragging = None
    
    # 窗口关闭事件
    # Window close event
    # ウィンドウ閉じるイベント
    def on_window_close(self):
        global adjustment_running
        adjustment_running = False
        self.root.destroy()
        save_config()
        print(Fore.GREEN + "Position adjustment window closed and positions saved." + Style.RESET_ALL)
        log_message("Position adjustment window closed and positions saved.")
    
    # 运行窗口
    # Run window
    # ウィンドウを実行
    def run(self):
        self.root.mainloop()
    
    # 关闭窗口
    # Close window
    # ウィンドウを閉じる
    def close(self):
        self.root.destroy()

# 位置改变回调函数
# Position change callback function
# 位置変更コールバック関数
def on_position_changed(time_x, time_y, channel_x, channel_y):
    global time_pos, channel_pos
    
    time_pos[0] = time_x
    time_pos[1] = time_y
    channel_pos[0] = channel_x
    channel_pos[1] = channel_y
    
    log_message(f"OSD positions updated - Time: ({time_x}, {time_y}), Channel: ({channel_x}, {channel_y})")

# 列出可用的相机（从0开始索引）
# List available cameras (0-based index)
# 利用可能なカメラをリストアップ（0から始まるインデックス）
def list_0based_cameras():
    available_cams = []
    print(Fore.CYAN + "Scanning available cameras (0-based index)..." + Style.RESET_ALL)
    log_message("Scanning available cameras (0-based index)...")
    
    for idx in range(10):
        cap = cv2.VideoCapture(idx)
        if cap.isOpened():
            w, h = cap.get(cv2.CAP_PROP_FRAME_WIDTH), cap.get(cv2.CAP_PROP_FRAME_HEIGHT)
            available_cams.append((idx, int(w), int(h)))
            cap.release()
    
    if not available_cams:
        print(Fore.RED + "Error: No cameras detected. Exiting..." + Style.RESET_ALL)
        log_message("Error: No cameras detected. Exiting...")
        return None
    
    print(Fore.GREEN + "\nAvailable Cameras (Index | Resolution):" + Style.RESET_ALL)
    log_message("Available Cameras:")
    for idx, w, h in available_cams:
        print(f"- Index: {Fore.YELLOW}{idx}{Style.RESET_ALL} | {w}x{h}")
        log_message(f"- Index: {idx} | {w}x{h}")
    
    while True:
        try:
            user_input = input("Enter 0-based camera index to open: ")
            selected_idx = int(user_input)
            
            if any(idx == selected_idx for idx, _, _ in available_cams):
                log_message(f"User selected camera index: {selected_idx}")
                return selected_idx
            else:
                valid_indices = ", ".join([str(idx) for idx, _, _ in available_cams])
                print(Fore.RED + f"Invalid index. Valid indices: {valid_indices}" + Style.RESET_ALL)
                log_message(f"Invalid camera index: {selected_idx}. Valid indices: {valid_indices}")
        except ValueError:
            print(Fore.RED + "Invalid input. Enter an integer (e.g., 0, 1)." + Style.RESET_ALL)
            log_message("Invalid input for camera index. Not an integer.")

# 命令监听器
# Command listener
# コマンドリスナー
def command_listener():
    global current_font_size, font, osd_color, channel_name, adjustment_window, show_adjustment_window, command_listener_running, video_infinite_mode, video_recording, time_format
    
    while command_listener_running:
        try:
            user_input = input().strip()
            
            log_message(f"User input: {user_input}")
            
            size_match = re.match(r'^osd_size:(\d+)$', user_input)
            if size_match:
                new_size = int(size_match.group(1))
                
                if 10 <= new_size <= 72:
                    old_size = current_font_size
                    current_font_size = new_size
                    font = load_custom_font(FONT_PATH, current_font_size)
                    print(Fore.GREEN + f"Font size changed to: {current_font_size}" + Style.RESET_ALL)
                    log_message(f"Font size changed from {old_size} to {current_font_size}")
                    save_config()
                else:
                    print(Fore.RED + f"Invalid font size. Please enter a value between 10 and 72." + Style.RESET_ALL)
                    log_message(f"Invalid font size: {new_size}. Not in range 10-72.")
                continue
            
            color_match = re.match(r'^osd_color:#([0-9A-Fa-f]{6})$', user_input)
            if color_match:
                color_hex = color_match.group(1)
                old_color = osd_color
                osd_color = tuple(int(color_hex[i:i+2], 16) for i in (0, 2, 4))
                print(Fore.GREEN + f"OSD color changed to: #{color_hex}" + Style.RESET_ALL)
                log_message(f"OSD color changed from {old_color} to #{color_hex}")
                save_config()
                continue
            
            if user_input == "osd_color:#i":
                old_color = osd_color
                osd_color = None
                print(Fore.GREEN + "OSD color set to automatic (based on background brightness)" + Style.RESET_ALL)
                log_message(f"OSD color changed from {old_color} to automatic")
                save_config()
                continue
            
            cname_match = re.match(r'^osd_Cname:(.+)$', user_input)
            if cname_match:
                old_name = channel_name
                channel_name = cname_match.group(1)
                print(Fore.GREEN + f"Channel name changed to: {channel_name}" + Style.RESET_ALL)
                log_message(f"Channel name changed from '{old_name}' to '{channel_name}'")
                save_config()
                continue
            
            time_format_match = re.match(r'^osd_time_format:([a-tA-T])$', user_input)
            if time_format_match:
                new_time_format = time_format_match.group(1).lower()
                
                if new_time_format in ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't']:
                    old_format = time_format
                    time_format = new_time_format
                    print(Fore.GREEN + f"Time format changed to: {time_format}" + Style.RESET_ALL)
                    log_message(f"Time format changed from {old_format} to {time_format}")
                    save_config()
                else:
                    print(Fore.RED + f"Invalid time format. Please use a letter from a to t." + Style.RESET_ALL)
                    log_message(f"Invalid time format: {new_time_format}. Not in range a-t.")
                continue
            
            if user_input == "osd_xywindow:drive":
                if not adjustment_running:
                    show_adjustment_window = True
                    print(Fore.GREEN + "Position adjustment window will be opened in the main thread." + Style.RESET_ALL)
                    log_message("Position adjustment window will be opened in the main thread.")
                else:
                    print(Fore.YELLOW + "Position adjustment window is already running." + Style.RESET_ALL)
                    log_message("Position adjustment window is already running.")
                continue
            
            if user_input == "restore:system":
                restore_default_settings()
                continue
            
            image_match = re.match(r'^image:(\d+)$', user_input)
            if image_match:
                count = int(image_match.group(1))
                capture_image(count)
                continue
            
            video_match = re.match(r'^video:(.+)$', user_input)
            if video_match:
                duration = video_match.group(1)
                start_video_recording(duration)
                continue
            
            if user_input == "video:none":
                stop_video_recording()
                continue
            
            print(Fore.RED + f"Unknown command: {user_input}. Available commands:" + Style.RESET_ALL)
            log_message(f"Unknown command: {user_input}")
            print(Fore.YELLOW + "  osd_size:{number} - Change OSD font size" + Style.RESET_ALL)
            print(Fore.YELLOW + "  osd_color:#FFFFFF - Set OSD font color" + Style.RESET_ALL)
            print(Fore.YELLOW + "  osd_color:#i - Set OSD color to automatic" + Style.RESET_ALL)
            print(Fore.YELLOW + "  osd_Cname:{name} - Set channel name" + Style.RESET_ALL)
            print(Fore.YELLOW + "  osd_time_format:{letter} - Set time format (a-t)" + Style.RESET_ALL)
            print(Fore.YELLOW + "  osd_xywindow:drive - Start position adjustment window" + Style.RESET_ALL)
            print(Fore.YELLOW + "  restore:system - Restore system default settings" + Style.RESET_ALL)
            print(Fore.YELLOW + "  image:{number} - Capture images" + Style.RESET_ALL)
            print(Fore.YELLOW + "  video:{time} - Record video (time format: HH:MM:SS or 'i' for infinite)" + Style.RESET_ALL)
            print(Fore.YELLOW + "  video:none - Stop video recording" + Style.RESET_ALL)
            
        except EOFError:
            log_message("EOF detected, stopping command listener")
            command_listener_running = False
            break
        except KeyboardInterrupt:
            log_message("Keyboard interrupt, stopping command listener")
            command_listener_running = False
            break

# 更新Tkinter窗口
# Update Tkinter window
# Tkinterウィンドウを更新
def update_tkinter_window():
    global adjustment_window, adjustment_running, show_adjustment_window, frame_for_adjustment
    
    if show_adjustment_window and not adjustment_running:
        show_adjustment_window = False
        adjustment_running = True
        
        adjustment_window = PositionAdjustmentWindow(on_position_changed, frame_for_adjustment)
        
        adjustment_window.run()
        
        adjustment_running = False

# 打印版本信息
# Print version information
# バージョン情報を印刷
def print_version():
    print(Fore.CYAN + VERSION_INFO + Style.RESET_ALL)
    log_message(f"Version information requested: {VERSION_INFO}")

# 主函数
# Main function
# メイン関数
def main():
    global font, frame_for_adjustment, camera_width, camera_height, cap
    
    log_message("Program started")
    log_message(f"Version: {VERSION_INFO}")
    
    load_config()
    
    font = load_custom_font(FONT_PATH, current_font_size)
    
    selected_cam = list_0based_cameras()
    if selected_cam is None:
        log_message("No camera selected, exiting program")
        return
    
    cap = cv2.VideoCapture(selected_cam)
    if not cap.isOpened():
        print(Fore.RED + f"Error: Failed to open camera (Index: {selected_cam})" + Style.RESET_ALL)
        log_message(f"Error: Failed to open camera (Index: {selected_cam})")
        return
    
    log_message(f"Camera opened with index: {selected_cam}")
    
    camera_width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    camera_height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    
    # 创建可调整大小的窗口
    # Create resizable window
    # サイズ変更可能なウィンドウを作成
    cv2.namedWindow(f"Camera Feed (Index: {selected_cam})", cv2.WINDOW_NORMAL)
    # 设置初始窗口大小为相机分辨率
    # Set initial window size to camera resolution
    # 初期ウィンドウサイズをカメラ解像度に設定
    cv2.resizeWindow(f"Camera Feed (Index: {selected_cam})", camera_width, camera_height)
    
    print(Fore.GREEN + f"\nCamera (Index: {selected_cam}) opened with resolution: {camera_width}x{camera_height}. Press 'q' to quit." + Style.RESET_ALL)
    log_message(f"Camera resolution: {camera_width}x{camera_height}")
    print(Fore.YELLOW + "You can change settings by typing:" + Style.RESET_ALL)
    print(Fore.YELLOW + "  osd_size:{number} (e.g., osd_size:30)" + Style.RESET_ALL)
    print(Fore.YELLOW + "  osd_color:#FFFFFF (set font color)" + Style.RESET_ALL)
    print(Fore.YELLOW + "  osd_color:#i (automatic color)" + Style.RESET_ALL)
    print(Fore.YELLOW + "  osd_Cname:{name} (set channel name)" + Style.RESET_ALL)
    print(Fore.YELLOW + "  osd_time_format:{letter} (set time format, a-t)" + Style.RESET_ALL)
    print(Fore.YELLOW + "  osd_xywindow:drive (start position adjustment window)" + Style.RESET_ALL)
    print(Fore.YELLOW + "  restore:system (restore system default settings)" + Style.RESET_ALL)
    print(Fore.YELLOW + "  image:{number} (capture images)" + Style.RESET_ALL)
    print(Fore.YELLOW + "  video:{time} (record video, time format: HH:MM:SS or 'i' for infinite)" + Style.RESET_ALL)
    print(Fore.YELLOW + "  video:none (stop video recording)" + Style.RESET_ALL)
    print(Fore.YELLOW + "\nTime format codes:" + Style.RESET_ALL)
    print(Fore.YELLOW + "  a: XXXX年XX月XX日 week XX：XX：XX" + Style.RESET_ALL)
    print(Fore.YELLOW + "  b: XX月XX日XXXX年 week XX：XX：XX" + Style.RESET_ALL)
    print(Fore.YELLOW + "  c: XX日XX月XXXX年 week XX：XX：XX" + Style.RESET_ALL)
    print(Fore.YELLOW + "  d: XXXX-XX-XX week XX：XX：XX" + Style.RESET_ALL)
    print(Fore.YELLOW + "  e: XX-XX-XXXX week XX：XX：XX" + Style.RESET_ALL)
    print(Fore.YELLOW + "  f: XX-XX-XXXX week XX：XX：XX" + Style.RESET_ALL)
    print(Fore.YELLOW + "  g: XXXX/XX/XX week XX：XX：XX" + Style.RESET_ALL)
    print(Fore.YELLOW + "  h: XX/XX/XXXX week XX：XX：XX" + Style.RESET_ALL)
    print(Fore.YELLOW + "  i: XX/XX/XXXX week XX：XX：XX" + Style.RESET_ALL)
    print(Fore.YELLOW + "  j: XX/XX/XXXX XX：XX：XX (no week)" + Style.RESET_ALL)
    print(Fore.YELLOW + "  k: XX-XX-XXXX XX：XX：XX (no week)" + Style.RESET_ALL)
    print(Fore.YELLOW + "  l: XX月XX日XXXX年 XX：XX：XX (no week)" + Style.RESET_ALL)
    print(Fore.YELLOW + "  m: XXXX年XX月XX日 XX：XX：XX (no week)" + Style.RESET_ALL)
    print(Fore.YELLOW + "  n: XX月XX日XXXX年 XX：XX：XX (no week)" + Style.RESET_ALL)
    print(Fore.YELLOW + "  o: XXXX-XX-XX XX：XX：XX (no week)" + Style.RESET_ALL)
    print(Fore.YELLOW + "  p: XXXX/XX/XX XX：XX：XX (no week)" + Style.RESET_ALL)
    print(Fore.YELLOW + "  q: XX-XX-XXXX XX：XX：XX (no week)" + Style.RESET_ALL)
    print(Fore.YELLOW + "  r: XX/XX/XXXX XX：XX：XX (no week)" + Style.RESET_ALL)
    print(Fore.YELLOW + "  s: XXXX年XX月XX日 XX：XX：XX (no week)" + Style.RESET_ALL)
    print(Fore.YELLOW + "  t: XX月XX日XXXX年 XX：XX：XX (no week)" + Style.RESET_ALL)
    
    listener_thread = threading.Thread(target=command_listener, daemon=True)
    listener_thread.start()
    
    try:
        while True:
            ret, frame = cap.read()
            if not ret:
                print(Fore.RED + "Error: Failed to read frame from camera" + Style.RESET_ALL)
                log_message("Error: Failed to read frame from camera")
                break
            
            frame_for_adjustment = frame.copy()
            
            frame_with_time = add_realtime_time_with_single_char_color(frame, font)
            
            global video_recording, video_writer, video_infinite_mode
            if video_recording and video_writer is not None:
                write_video_frame(video_writer, frame_with_time)
            
            window_width = cv2.getWindowImageRect(f"Camera Feed (Index: {selected_cam})")[2]
            window_height = cv2.getWindowImageRect(f"Camera Feed (Index: {selected_cam})")[3]
            
            if window_width > 0 and window_height > 0 and (window_width != camera_width or window_height != camera_height):
                frame_with_time = cv2.resize(frame_with_time, (window_width, window_height))
            
            cv2.imshow(f"Camera Feed (Index: {selected_cam})", frame_with_time)
            
            global show_adjustment_window
            if show_adjustment_window:
                update_tkinter_window()
            
            global adjustment_running, adjustment_window
            if adjustment_running and adjustment_window:
                adjustment_window.update_frame(frame_for_adjustment)
            
            if cv2.waitKey(1) & 0xFF == ord('q'):
                break
    finally:
        if video_recording:
            stop_video_recording()
        
        if cap is not None and cap.isOpened():
            cap.release()
        
        cv2.destroyAllWindows()
        
        if adjustment_running and adjustment_window:
            adjustment_window.close()
        
        global command_listener_running
        command_listener_running = False
        
        if listener_thread.is_alive():
            listener_thread.join(timeout=1.0)
        
        print(Fore.CYAN + "\nCamera closed successfully." + Style.RESET_ALL)
        log_message("Program ended normally")

# 程序入口点
# Program entry point
# プログラムのエントリーポイント
if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='AOS USB Camera')
    parser.add_argument('-v', '--version', action='store_true', help='Show version information')
    args = parser.parse_args()
    
    if args.version:
        print_version()
    else:
        main()
